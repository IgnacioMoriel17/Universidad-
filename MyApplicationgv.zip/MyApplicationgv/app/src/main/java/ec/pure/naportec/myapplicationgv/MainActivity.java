package ec.pure.naportec.myapplicationgv;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity  {
Button falso,verdadero, reset;
LinearLayout integrantes, abririnte;
ImageButton expandir;
boolean abierto=false;
int acumulador=0;
int manejadordepreguntas=0;

TextView pregunta, numpregunta, score;

List<Preguntas> listaPreguntas = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        falso=findViewById(R.id.btn1);
        verdadero=findViewById(R.id.btn2);
        reset=findViewById(R.id.reset);

        pregunta=findViewById(R.id.lapregunta);
        numpregunta=findViewById(R.id.numero_pregunta);
        score=findViewById(R.id.score);

        llenarPreguntas();
        vista();





        falso.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                evaluar(0);



            }
        });
        verdadero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                evaluar(1);
            }
        });
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                acumulador=0;
                manejadordepreguntas=0;
                vista();
            }
        });




    }
    public void evaluar(int respuesta)
    {
        if(manejadordepreguntas<listaPreguntas.size())
        {
            if(listaPreguntas.get(manejadordepreguntas).getRespuesta())
            {
                if(respuesta==1)
                {
                    acumulador=acumulador+100;
                    Toast.makeText(getApplicationContext(),"Respuesa Correcta",Toast.LENGTH_LONG).show();
                }
                else
                {
                    Toast.makeText(getApplicationContext(),"Respuesta incorrecta",Toast.LENGTH_LONG).show();
                    acumulador=acumulador-50;
                }

            }else
            {
                if(respuesta==0)
                {
                    acumulador=acumulador+100;
                    Toast.makeText(getApplicationContext(),"Respuesa Correcta",Toast.LENGTH_LONG).show();
                }
                else
                {
                    Toast.makeText(getApplicationContext(),"Respuesta incorrecta",Toast.LENGTH_LONG).show();
                    acumulador=acumulador-50;
                }
            }


            manejadordepreguntas=manejadordepreguntas+1;
            if(manejadordepreguntas<listaPreguntas.size())
                vista();
        }
        else
        {
            androidx.appcompat.app.AlertDialog alertDialog = new androidx.appcompat.app.AlertDialog.Builder(MainActivity.this).create();
            alertDialog.setTitle("Atención");
            alertDialog.setCancelable(false);
            alertDialog.setMessage("Su resultado es: " +acumulador);
            alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Salir",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            acumulador=0;
                            manejadordepreguntas=0;
                            vista();
                            dialog.dismiss();
                        }
                    });
            alertDialog.show();
        }



    }

    public void vista()
    {
        score.setText(String.valueOf(acumulador));
        numpregunta.setText("Pregunta: "+(manejadordepreguntas+1));
        pregunta.setText(listaPreguntas.get(manejadordepreguntas).getPregunta());
    }

    public void llenarPreguntas()
    {
        Preguntas p1 = new Preguntas();
        Preguntas p2 = new Preguntas();
        Preguntas p3 = new Preguntas();
        Preguntas p4 = new Preguntas();
        Preguntas p5 = new Preguntas();
        p1.setPregunta("ANDROID ES UN SISTEMA DE CODIGO ABIERTO?");
        p1.setRespuesta(true);
        p2.setPregunta("ANDROID ESTA BASADO EN JAVA?");
        p2.setRespuesta(true);
        p3.setPregunta("EL SISTEMA IOS ES DE GOOGLE ?");
        p3.setRespuesta(false);
        p4.setPregunta("CON ANDROID SE PUEDE CREAR APP MOVILES");
        p4.setRespuesta(true);
        p5.setPregunta("ANDROID REPOSITORIO DE CODIGO ?");
        p5.setRespuesta(false);
        listaPreguntas.add(p1);
        listaPreguntas.add(p2);
        listaPreguntas.add(p3);
        listaPreguntas.add(p4);
        listaPreguntas.add(p5);
        
    }
}




