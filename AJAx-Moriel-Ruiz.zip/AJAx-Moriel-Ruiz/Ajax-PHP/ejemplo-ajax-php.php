<html>

<head>
<script>
function showHint(str) {
  if (str.length == 0) {
    document.getElementById("txtHint").innerHTML = "";
    return;
  } else {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        document.getElementById("txtHint").innerHTML = this.responseText;
      }
    };
    xmlhttp.open("GET", "obtener_datos.php?q=" + str, true);
    xmlhttp.send();
  }
}
</script>
</head>
<body align="center" style="padding-top: 150px;">

    <p><b>Escriba un nombre en la caja de texto ;)</b></p>
    <form action="">
        <label for="fname">Escribe un nombre:</label>
        <input type="text" id="fname" name="fname" onkeyup="showHint(this.value)">
    </form>
    <p>Segerencia: <span id="txtHint"></span></p>

    <p style="text-align: center;"> Copyright © <?php echo date('d-m-Y'); ?> Ajax Moriel :)</p>
</body>
</html>