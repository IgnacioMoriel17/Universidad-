<?php
session_start();
require 'conexion.php';
$user = $_POST['usuario'];
$clave = $_POST['clave'];


$query = "SELECT COUNT(*) as contar FROM usuarios where username = '$user' and password = '$clave' ";
$bdconect = mysqli_query($conectar,$query);
$parametros = mysqli_fetch_array($bdconect);
if($parametros['contar']>0){
   $_SESSION['username'] = $user;
  /*header("location: ../paginaprincipal.php");*/
  header("location: ../home/inicio.php");
}else {
   header("location: ../login/no_registrado.html");

    /*echo "<h1>datos incorrectos</h1> <br> ";
    echo "<a href='../index.html'>Volver</a>";*/
}


?>