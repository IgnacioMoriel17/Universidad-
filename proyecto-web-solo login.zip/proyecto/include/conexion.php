<?php
 $host = "localhost";
 $user = "root";
 $clave = "";
 $bd = "workbookbd2";
 $conectar = mysqli_connect($host,$user,$clave,$bd);
 ?>