<!DOCTYPE html>
<html>
<head>
	<title>Registrar usuario</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="estillos1.css">
	<link href="https://unpkg.com/ionicons@4.5.5/dist/css/ionicons.min.css" rel="stylesheet">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
        integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
</head>
<body>
	<nav class="navbar navbar-expand-lg">
        <div class="container">
            <a class="navbar-brand disabled animate__animated animate__slideInLeft"
                style="font-size: 35px; color: with;">WorkBook</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <i class="icon ion-md-menu"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item"><a class="nav-link" href="../index.html" id="login" style="font-weight: 700 ;" >Volver</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <h2 style="text-align: center;padding: 40px; font-weight: 300"> Buscas un nueva fuente de trabajo, registrate y ponte en contacto con profecionales y empresas.</h2>

    <form method="post">
    	<h1>¡Registrate! </h1>
     	<input type="text" name="user" placeholder="usuario">
		<input type="text" name="pass" placeholder="contraseña">
        <input type="text" name="name" placeholder="Nombre completo">
        <input type="text" name="cedu" placeholder="Cedula">
        <input type="text" name="email" placeholder="Correo">
        <input type="text" name="cel" placeholder="Celular">
        <input type="text" name="dir" placeholder="Direccion">
        <input type="text" name="ciudad" placeholder="Ciudad">
        <input type="text" name="titulo" placeholder="Titulo">
        <input type="text" name="prof" placeholder="Profesion">
		<input type="submit" name="register">
    </form>
        <?php 
        include("registrar.php");
		?>
        
        

        
	<footer class="bgDark">
        <div class="container">
            <h2 style="font-size: 30px; color:rgb(95, 204, 255)"><b>WorkBook</b></h2>
            <ul class="list-inline">
                <li class="list-inline-item footer-menu"><a href="../formulario/from_contacto_login.html"
                        style="font-weight: 700;">Contacto</a></li>
                <li class="list-inline-item footer-menu"><a href="../login/terminosycondic_login.html" style="font-weight: 700;">Terminos y Condiciones
                        </a></li>
            </ul>
           
            <small><b>Desarrollo de Aplicaicones WEB UG.</b> ©2020 All Rights Reserved. Created by Grupo </small>
        </div>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"
        integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN"
        crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"
        integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV"
        crossorigin="anonymous"></script>
</body>
</html>