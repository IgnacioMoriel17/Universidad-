<!doctype html>
<html lang="es">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Fuente -->
    <link href="https://fonts.googleapis.com/css?family=Titillium+Web:400,600" rel="stylesheet">
    <link href="estilosacerca.css" rel="stylesheet">
    <link href="https://unpkg.com/ionicons@4.5.5/dist/css/ionicons.min.css" rel="stylesheet">
    <!--Animacion de ciertas Etiquetas-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.0.0/animate.min.css" />
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
        integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">


    <title>Acerca de nosotros</title>
</head>

<body>

    <nav class="navbar navbar-expand-lg">
        <div class="container">
            <a class="navbar-brand nav-link disabled animate__animated animate__slideInLeft"
                style="font-size: 35px; color: white;">Bienvenido a <span
                    style="color:rgb(95, 204, 255)">WorkBook</span></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <i class="icon ion-md-menu"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item pt-2 active"><a class="nav-link" href="inicio.php" id="inicio">Home</a></li>
                    <li class="nav-item pt-2"><a class="nav-link" href="publicaciones.php" id="publicaciones">Publicaciones</a></li>
                    

                    <li class="nav-item "><a class="nav-link" href="info_user.php" style="font-size: 23px;font-weight: 600 ;color:  rgb(95, 204, 255)">
                        <?php
                            session_start();
                            $sesion = $_SESSION['username'];
                            if(!isset($sesion)){
                                header("location: ../index.html");
                            }else{
                                echo " $sesion ";
                            }

                        ?></a></li>

                    <li class="nav-item pt-2"><a class="nav-link" href="../index.html" id="salir">Salir</a></li>

                </ul>

            </div>
        </div>
    </nav>
    <main>
        <section id="estudiantes" class="divider">
            <h2 style="text-align: center;padding: 20px; font-weight: 500">Acerca de nosotros </h2>
            <h3 style="text-align: center;padding: 20px; font-weight: 300">Somos Estudiantes de la Facultad de
                Ingenieria en Sistemas Computacionales y hemos desarrollado una red social para profecionales y para
                empresas con la finalidad de sus agrado ;) </h3>
            <div class="container">
                <div class="content-center">

                    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <div class="carousel-container">
                                    <p>Hola mi nombre es Ignacio Moriel y soy responsable del diseno de la pag web como
                                        pasatiempos tengo hacer ejercicio y me gusta mucho la Programacion
                                    </p>
                                    <div class="rating">
                                        <ul class="list-inline">
                                            <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                            <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                            <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                            <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                            <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                        </ul>
                                    </div>
                                    <div class="estudiantes-user">
                                        <div class="row">
                                            <div class="col-md-3 col-3">
                                                <img src="../imagenes/moriel.jpeg" class="img-fluid" alt="">
                                            </div>
                                            <div class="col-md-9 col-9">
                                                <h6>Ignacio Moriel</h6>
                                                <span>Diseño con CSS y Bootstrap</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="carousel-container">
                                    <p>Hola mi nombre es Ma.Angeles me gusta mucho la carrera, en especial las materias
                                        de programacion. Hobbie favorito es ver peliculas.</p>
                                    <div class="rating">
                                        <ul class="list-inline">
                                            <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                            <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                            <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                            <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                            <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                        </ul>
                                    </div>
                                    <div class="estudiantes-user">
                                        <div class="row">
                                            <div class="col-md-3 col-3">
                                                <img src="../imagenes/briones.jpg" class="img-fluid" alt="">
                                            </div>
                                            <div class="col-md-9 col-9">
                                                <h6>Maria de Los Angeles Briones</h6>
                                                <span>Desarrollo</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="carousel-container">
                                    <p>Mi nombres es Kevin García, cuento con 23 años. Mi perfil profesional apunta al
                                        desarrollo de aplicaciones en diferentes tipos de lenguaje, soporte técnico a
                                        equipos de cómputo preventivos y correctivos, colaborativo en el área de
                                        trabajo, sociable y dispuesto ayudar con dudas e inquietudes sobre la carrera de
                                        ingeniería en sistemas computacionales.</p>
                                    <div class="rating">
                                        <ul class="list-inline">
                                            <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                            <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                            <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                            <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                            <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                        </ul>
                                    </div>
                                    <div class="estudiantes-user">
                                        <div class="row">
                                            <div class="col-md-3 col-3">
                                                <img src="../imagenes/garcia1.jpg" class="img-fluid" alt="">
                                            </div>
                                            <div class="col-md-9 col-9">
                                                <h6>Gracia Chamba</h6>
                                                <span>Validaciones</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button"
                            data-slide="prev">
                            <div class="control-button">
                                <img src="../imagenes/iconos/arrow-borderless-left.svg" class="img-fluid" alt="arrowl">
                            </div>
                            <span class="sr-only">Previous</span>
                        </a>
                        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button"
                            data-slide="next">
                            <div class="control-button">
                                <img src="../imagenes/iconos/arrow-borderless-right.svg" class="img-fluid" alt="arrowr">
                            </div>
                            <span class="sr-only">Next</span>
                        </a>
                    </div>
                </div>
            </div>
        </section>

    </main>
    <footer class="bgDark">
        <div class="container">
            <h2 style="font-size: 30px; color:rgb(95, 204, 255)"><b>WorkBook</b></h2>
            <ul class="list-inline">
                <li class="list-inline-item footer-menu"><a href="inicio.html">Inicio</a></li>
                <li class="list-inline-item footer-menu">
                    <a class="nav-link dropdown-toggle" href="#" id="anuncia" role="button" data-toggle="dropdown"
                        aria-haspopup="true" aria-expanded="false">Anuncia</a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="../formulario/formulario_profesional.html">Presonas</a>
                        <a class="dropdown-item" href="../formulario/formulario_empresa.html">Empresa</a>
                    </div>
                </li>
                <li class="list-inline-item footer-menu"><a href="acercade.html">Acerca de Nosotros</a></li>
                <li class="list-inline-item footer-menu"><a href="../formulario/formulariocontac.html">Contact</a></li>
                <li class="list-inline-item footer-menu"><a href="terminoycondiciones.html">Termino y Condiciones</a></li>
            </ul>
            <ul class="list-inline">
                <li class="list-inline-item"><a href="http://www.instagram.com"><i
                            class="icon ion-logo-instagram"></i></a></li>
                <li class="list-inline-item"><a href="http://www.facebook.com"><i
                            class="icon ion-logo-facebook"></i></a></li>
                <li class="list-inline-item"><a href="http://www.youtube.com"><i class="icon ion-logo-youtube"></i></a>
                </li>
                <li class="list-inline-item"><a href="http://www.whatsapp.com"><i
                            class="icon ion-logo-whatsapp"></i></a></li>
                <li class="list-inline-item"><a href="http://www.twitter.com"><i class="icon ion-logo-twitter"></i></a>
                </li>
            </ul>
            <small>©2020 All Rights Reserved. Created by Grupo <b>D.A.W con Bootstrap</b></small>
        </div>
    </footer>


    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"
        integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN"
        crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"
        integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV"
        crossorigin="anonymous"></script>

</body>

</html>