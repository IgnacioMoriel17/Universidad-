<!doctype html>
<html lang="es">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Fuente -->
    <link href="https://fonts.googleapis.com/css?family=Titillium+Web:400,600" rel="stylesheet">
    <link href="estiloscomercio1.css" rel="stylesheet">
    <link href="https://unpkg.com/ionicons@4.5.5/dist/css/ionicons.min.css" rel="stylesheet">
    <!--Animacion de ciertas Etiquetas-->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.0.0/animate.min.css" />
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
        integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">


    <title>Publicaciones</title>
</head>

<body>


    <nav class="navbar navbar-expand-lg">
        <div class="container">
            <a class="navbar-brand nav-link disabled animate__animated animate__slideInLeft"
				style="font-size: 35px; color: white;">Bienvenido a <span style="color: rgb(95, 204, 255);">WorkBook</span></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <i class="icon ion-md-menu"></i>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item pt-2 active"><a class="nav-link" href="inicio.php" id="inicio">Home</a></li>
                   
                    
                    <li class="nav-item pt-2"><a class="nav-link" href="acercade.php" id="acerca">Acerca de Nosotros</a></li>
                    <li class="nav-item "><a class="nav-link " href="info_user.php" style="font-size: 23px;font-weight: 600 ;color:  rgb(95, 204, 255)">
                        <?php
                            session_start();
                            $sesion = $_SESSION['username'];
                            if(!isset($sesion)){
                                header("location: ../index.html");
                            }else{
                                echo " $sesion ";
                            }

                        ?></a></li>
                    <li class="nav-item pt-2"><a class="nav-link" href="../index.html" id="salir">Salir</a></li>
                </ul>

            </div>
        </div>
    </nav>
    <main>
        <h2 style="text-align: center;padding: 20px; font-weight: 300" class="divider">Lo mas Reciente </h2>



        <section class="divider">
            <div class="container">
                <div class="content-center">

                    <div id="carruselindicado1" class="carousel slide" data-ride="carousel">
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <div class="carousel-container">
                                    <div class="col-md-3 col-3">
                                        <img src="../imagenes/rosadox1.jpg" class="img-fluid" alt="rosadox1">
                                    </div>
                                    <h5>Venta al por menor de gran variedad de productos entre los que predominan, los
                                        productos alimenticios, las bebidas o el tabaco, como productos de primera
                                        necesidad y varios otros tipos de productos, como prendas de vestir, muebles,
                                        aparatos, artículo </h5>
                                    <input type="button" id="btn" value="Agregar"
                                        style="border-radius: 30px;background-color: black; color: white; margin-left: 20px;font-size:22px">
                                    <div class="rating" style="text-align: right">
                                        <ul class="list-inline">
                                            <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                            <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                            <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                            <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                            <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                        </ul>
                                    </div>
                                    <div class="estudiantes-user">
                                        <div class="row">

                                            <div class="col-md-9 col-9">

                                                <h6 style="font-weight: 800;">Coorporacion El Rosado</h6>
                                                <span>Retail</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="carousel-container">
                                    <h6>Venta al por menor de gran variedad de productos entre los que predominan, los
                                        productos alimenticios, las bebidas o el tabaco, como productos de primera
                                        necesidad y varios otros tipos de productos, como prendas de vestir, muebles,
                                        aparatos, artículo</h6>

                                    <div class="estudiantes-user">
                                        <div class="row">

                                            <div class="col-md-9 col-9">
                                                <h6 style="font-weight: 800;">Coorporacion el Rosado</h6>
                                                <span>Retail</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <a class="carousel-control-prev" href="#carruselindicado1" role="button" data-slide="prev">
                            <div class="control-button">
                                <img src="../imagenes/iconos/arrow-borderless-left.svg" class="img-fluid" alt="arroel">
                            </div>
                            <span class="sr-only">Previous</span>
                        </a>
                        <a class="carousel-control-next" href="#carruselindicado1" role="button" data-slide="next">
                            <div class="control-button">
                                <img src="../imagenes/iconos/arrow-borderless-right.svg" class="img-fluid" alt="arrowr">
                            </div>
                            <span class="sr-only">Next</span>
                        </a>
                    </div>
                </div>
            </div>
        </section>


        <section class="divider">
            <div class="container">
                <div class="content-center">
                    <div id="carruselindicado3" class="carousel slide" data-ride="carousel">
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <div class="carousel-container">
                                    <div class="col-md-3 col-3">
                                        <img src="../imagenes/zack1.jpg" class="img-fluid" alt="zack1">
                                    </div>
                                    <h5>Hola con todos me llamo Juan gomez y soy programador en python con maestris en
                                        Cambrigde tambien diseño paginas web como pasatiempos.</h5>
                                    <input type="button" id="btn1" value="Agregar"
                                        style="border-radius: 30px;background-color: black; color: white; margin-left: 20px;font-size:22px">
                                    <div class="rating" style="text-align: right">
                                        <ul class="list-inline">
                                            <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                            <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                            <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                            <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                            <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                        </ul>
                                    </div>
                                    <div class="estudiantes-user">
                                        <div class="row">

                                            <div class="col-md-9 col-9">
                                                <h6 style="font-weight: 800;">Juan Gomez</h6>
                                                <span>Desarrollador en Python</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="carousel-container">
                                    <h6>Hola con todos me llamo Juan gomez y soy programador en python con maestris en
                                        Cambrigde tambien diseño paginas web como pasatiempos.</h6>
                                    <div class="estudiantes-user">
                                        <div class="row">

                                            <div class="col-md-9 col-9">
                                                <h6 style="font-weight: 800;">Juan Gomez</h6>
                                                <span>Desarrollador en Python</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <a class="carousel-control-prev" href="#carruselindicado3" role="button" data-slide="prev">
                            <div class="control-button">
                                <img src="../imagenes/iconos/arrow-borderless-left.svg" class="img-fluid" alt="arroel">
                            </div>
                            <span class="sr-only">Previous</span>
                        </a>
                        <a class="carousel-control-next" href="#carruselindicado3" role="button" data-slide="next">
                            <div class="control-button">
                                <img src="../imagenes/iconos/arrow-borderless-right.svg" class="img-fluid" alt="arrowr">
                            </div>
                            <span class="sr-only">Next</span>
                        </a>
                    </div>
                </div>
            </div>
        </section>


        <section class="divider">
            <div class="container">
                <div class="content-center">

                    <div id="carruselindicado2" class="carousel slide" data-ride="carousel">
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <div class="carousel-container">
                                    <div class="col-md-3 col-3">
                                        <img src="../imagenes/nova.jpg" class="img-fluid" alt="">
                                    </div>
                                    <h5>NOVACERO S.A. dedicada a fabricación de barras, varillas y secciones sólidas de
                                        hierro y acero laminadas en caliente y mediante estirado en frío y en caliente
                                    </h5>
                                    <input type="button" id="btn2" value="Agregar"
                                        style="border-radius: 30px;background-color: black; color: white; margin-left: 20px;font-size:22px">
                                    <div class="rating" style="text-align: right">
                                        <ul class="list-inline">
                                            <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                            <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                            <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                            <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                            <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                        </ul>
                                    </div>
                                    <div class="estudiantes-user">
                                        <div class="row">

                                            <div class="col-md-9 col-9">
                                                <h6 style="font-weight: 800;">Novacero</h6>
                                                <span>Industria</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="carousel-container">
                                    <h6>NOVACERO S.A. dedicada a fabricación de barras, varillas y secciones sólidas de
                                        hierro y acero laminadas en caliente y mediante estirado en frío y en caliente
                                    </h6>

                                    <div class="estudiantes-user">
                                        <div class="row">

                                            <div class="col-md-9 col-9">
                                                <h6 style="font-weight: 800;">Novacero</h6>
                                                <span>Industria</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <a class="carousel-control-prev" href="#carruselindicado2" role="button" data-slide="prev">
                            <div class="control-button">
                                <img src="../imagenes/iconos/arrow-borderless-left.svg" class="img-fluid" alt="arroel">
                            </div>
                            <span class="sr-only">Previous</span>
                        </a>
                        <a class="carousel-control-next" href="#carruselindicado2" role="button" data-slide="next">
                            <div class="control-button">
                                <img src="../imagenes/iconos/arrow-borderless-right.svg" class="img-fluid" alt="arrowr">
                            </div>
                            <span class="sr-only">Next</span>
                        </a>
                    </div>
                </div>
            </div>
        </section>


        <section class="divider">
            <div class="container">
                <div class="content-center">

                    <div id="carruselindicado4" class="carousel slide" data-ride="carousel">
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <div class="carousel-container">
                                    <div class="col-md-3 col-3">
                                        <img src="../imagenes/mujer1.jpg" class="img-fluid" alt="">
                                    </div>
                                    <h5>Soy Maria Gutierrez y me desempeño en administrar y gestionar proyectos soy
                                        responsable dedica y comprometida con mi trabajo</h5>
                                    <input type="button" id="btn3" value="Agregar"
                                        style="border-radius: 30px;background-color: black; color: white; margin-left: 20px;font-size:22px">
                                    <div class="rating" style="text-align: right">
                                        <ul class="list-inline">
                                            <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                            <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                            <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                            <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                            <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                        </ul>
                                    </div>
                                    <div class="estudiantes-user">
                                        <div class="row">

                                            <div class="col-md-9 col-9">
                                                <h6 style="font-weight: 800;">Maria Gutierrez</h6>
                                                <span>Administracion de Proyectos</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="carousel-container">
                                    <h6>Soy Maria Gutierrez y me desempeño en administrar y gestionar proyectos soy
                                        responsable dedica y comprometida con mi trabajo</h6>
                                    <div class="estudiantes-user">
                                        <div class="row">

                                            <div class="col-md-9 col-9">
                                                <h6 style="font-weight: 800;">Maria Gutierrez</h6>
                                                <span>Administracion de Proyectos</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <a class="carousel-control-prev" href="#carruselindicado4" role="button" data-slide="prev">
                            <div class="control-button">
                                <img src="../imagenes/iconos/arrow-borderless-left.svg" class="img-fluid" alt="arroel">
                            </div>
                            <span class="sr-only">Previous</span>
                        </a>
                        <a class="carousel-control-next" href="#carruselindicado4" role="button" data-slide="next">
                            <div class="control-button">
                                <img src="../imagenes/iconos/arrow-borderless-right.svg" class="img-fluid" alt="arrowr">
                            </div>
                            <span class="sr-only">Next</span>
                        </a>
                    </div>
                </div>
            </div>
        </section>


        <section class="divider">
            <div class="container">
                <div class="content-center">
                    <div id="carruselindicado5" class="carousel slide" data-ride="carousel">
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <div class="carousel-container">
                                    <div class="col-md-3 col-3">
                                        <img src="../imagenes/cerveceriax1.jpg" class="img-fluid" alt="">
                                    </div>
                                    <h5>Cervecería Nacional CN S.A., es la primera compañía dedicada a la elaboración y
                                        comercialización de bebidas de moderación y refrescos en Ecuador. Sus productos
                                        son elaborados en dos plantas cerveceras ubicadas en Guayaquil y Quito.
                                        Pertenece a la multinacional Anheuser-Busch InBev.</h5>
                                    <input type="button" id="btn4" value="Agregar"
                                        style="border-radius: 30px;background-color: black; color: white; margin-left: 20px;font-size:22px">
                                    <div class="rating" style="text-align: right">
                                        <ul class="list-inline">
                                            <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                            <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                            <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                            <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                            <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                        </ul>
                                    </div>
                                    <div class="estudiantes-user">
                                        <div class="row">

                                            <div class="col-md-9 col-9">
                                                <h6 style="font-weight: 800;">Cerveceria Nacional</h6>
                                                <span>Distribuidora</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="carousel-container">
                                    <h6>Cervecería Nacional CN S.A., es la primera compañía dedicada a la elaboración y
                                        comercialización de bebidas de moderación y refrescos en Ecuador. Sus productos
                                        son elaborados en dos plantas cerveceras ubicadas en Guayaquil y Quito.
                                        Pertenece a la multinacional Anheuser-Busch InBev.</h6>

                                    <div class="estudiantes-user">
                                        <div class="row">

                                            <div class="col-md-9 col-9">
                                                <h6 style="font-weight: 800;">Cerveceria Nacional</h6>
                                                <span>Distribuidora</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <a class="carousel-control-prev" href="#carruselindicado5" role="button" data-slide="prev">
                            <div class="control-button">
                                <img src="../imagenes/iconos/arrow-borderless-left.svg" class="img-fluid" alt="arroel">
                            </div>
                            <span class="sr-only">Previous</span>
                        </a>
                        <a class="carousel-control-next" href="#carruselindicado5" role="button" data-slide="next">
                            <div class="control-button">
                                <img src="../imagenes/iconos/arrow-borderless-right.svg" class="img-fluid" alt="arrowr">
                            </div>
                            <span class="sr-only">Next</span>
                        </a>
                    </div>
                </div>
            </div>
        </section>
    </main>


    <footer class="bgDark">
        <div class="container">
            <h2 style="font-size: 30px; color: rgb(95, 204, 255);"><b>WorkBook</b></h2>
            <ul class="list-inline">
                <li class="list-inline-item footer-menu"><a href="inicio.html">Inicio</a></li>
                <li class="list-inline-item footer-menu">
                    <a class="nav-link dropdown-toggle" href="#" id="lugaresx" role="button" data-toggle="dropdown"
                        aria-haspopup="true" aria-expanded="false">Anuncia</a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="../formulario/formulario_profesional.html">Presonas</a>
                        <a class="dropdown-item" href="../formulario/formulario_empresa.html">Empresa</a>
                    </div>
                </li>
                <li class="list-inline-item footer-menu"><a href="acercade.html">Acerca de Nosotros</a></li>
                <li class="list-inline-item footer-menu"><a href="../formulario/formulariocontac.html">Contact</a></li>
                <li class="list-inline-item footer-menu"><a href="terminoycondiciones.html">Termino y Condiciones</a></li>
            </ul>
            <ul class="list-inline">
                <li class="list-inline-item"><a href="http://www.instagram.com"><i
                            class="icon ion-logo-instagram"></i></a></li>
                <li class="list-inline-item"><a href="http://www.facebook.com"><i
                            class="icon ion-logo-facebook"></i></a></li>
                <li class="list-inline-item"><a href="http://www.youtube.com"><i class="icon ion-logo-youtube"></i></a>
                </li>
                <li class="list-inline-item"><a href="http://www.whatsapp.com"><i
                            class="icon ion-logo-whatsapp"></i></a></li>
                <li class="list-inline-item"><a href="http://www.twitter.com"><i class="icon ion-logo-twitter"></i></a>
                </li>
            </ul>
            <small>©2020 All Rights Reserved. Created by Grupo <b>D.A.W con Bootstrap</b></small>
        </div>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"
        integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN"
        crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"
        integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV"
        crossorigin="anonymous"></script>

</body>

</html>