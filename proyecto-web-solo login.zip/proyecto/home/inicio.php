
<!doctype html>
<html lang="es">

<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link href="estilosinicio.css" rel="stylesheet">
	<link href="https://unpkg.com/ionicons@4.5.5/dist/css/ionicons.min.css" rel="stylesheet">
	<!--Animacion de ciertas Etiquetas-->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.0.0/animate.min.css" />
	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
		integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
	<!--Efecto Scroll en imagen-->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
	<script src="parallax.min.js"></script>

	<title>Inicio</title>
</head>

<body>
	<nav class="navbar navbar-expand-lg">
		<div class="container">
			<a class="navbar-brand nav-link disabled animate__animated animate__slideInLeft"
				style="font-size: 35px; color: white;">Bienvenido a <span>WorkBook </span>  </a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
				aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
				<i class="icon ion-md-menu"></i>
			</button>
			<div class="collapse navbar-collapse" id="navbarSupportedContent">
				<ul class="navbar-nav ml-auto ">

					<li class="nav-item pt-2"><a class="nav-link" href="publicaciones.php" id="publicaciones">Publicaciones</a>
					</li>
					
					<li class="nav-item pt-2"><a class="nav-link" href="acercade.php" id="acerca">Acerca de Nosotros</a></li>
					<li class="nav-item "><a class="nav-link" href="info_user.php" style="font-size: 23px;font-weight: 600 ;color:  rgb(95, 204, 255)">
						<?php
							session_start();
							$sesion = $_SESSION['username'];
							if(!isset($sesion)){
								header("location: ../index.html");
							}else{
								echo " $sesion ";
							}

						?></a></li>
					<li class="nav-item pt-2"><a class="nav-link" href="../include/salir.php" id="salir">Salir</a></li>
				</ul>
			</div>
		</div>
	</nav>



	<section class="fondo" data-parallax="scroll" data-z-index="-1" data-image-src="../imagenes/men1.jpg">

		<div class="palabrascentro" >
			<h1> <span>WorkBook</span> la Red Social para Profesionales</h1>
			<!---->
		</div>

	</section>

	<section>
		<div class="container-fluid">
			<div class="palabrascentro">
				<h2 style="font-weight: 300">Miles profecionales a la espera de ofrecer sus servios en cualquier parte
					del Ecuador. </h2>
				<p><span><b>WorkBook</b></span> se basa en recopilar informacion de personas preparadas de todas las
					areas de
					profeciones a la espera de tener un trabajo o brindar uno.</p>
			</div>
		</div>
	</section>

	<section class="fondo" data-parallax="scroll" data-z-index="-1" data-image-src="../imagenes/women.jpg">
		<div class="palabrascentro2">
			<h3>Conoce personas que compratan la misma Profesion que tu </h3>
		</div>
	</section>

	<section>
		<div class="container-fluid">
			<div class="palabrascentro">
				<h2 style="font-weight: 300"> <span><b>WorkBook</b></span> te permite conectar con personas que realizan la
					misma profesion con que tu describas en tu perfil (o una similar).</h2>

			</div>
		</div>
	</section>

	<section class="fondo" data-parallax="scroll" data-z-index="-1" data-image-src="../imagenes/people6.jpg">
		<div class="palabrascentro">
			<h3>¿Buscas un nuevo trabajo?<br>
				¿Tu empresa nesecita el servicio de algun profecional?<br></h3>
			<h4 style="color:white; font-weight: 800; font-size: 70px;">Estas en el Lugar indicado ;)</h4>
		</div>
	</section>

	<section>
		<div class="container-fluid">
			<div class="palabrascentro">
				<h2 style="font-weight: 300">Prueba ahora mismo con lo siguiente... </h2>

			</div>
		</div>
	</section>

	<div class="row" style="margin-left: 30px;">
		<div class="col-md-6">
			<div class="portfolio-container">
				<div class="portfolio-details">
					<a>
						<h2>Busca algun servicio Profecional</h2>
					</a>
				</div>
				<img src="../imagenes/trabajox.jpg" class="img-fluid" alt="Portfolio 01">
			</div>
		</div>

		<div class="col-md-6">
			<div class="portfolio-container">
				<div class="portfolio-details">
					<a>
						<h2>Ofrce tus Servicos</h2>
					</a>

				</div>
				<img src="../imagenes/serviciox.jpg" class="img-fluid" alt="Portfolio 02">
			</div>
		</div>
		<div class="col-md-6">
			<div class="portfolio-container">
				<div class="portfolio-details">
					<a>
						<h2>Comparte Experiencias</h2>
					</a>

				</div>
				<img src="../imagenes/compartex.jpg" class="img-fluid" alt="Portfolio 03">
			</div>
		</div>
		<div class="col-md-6">
			<div class="portfolio-container">
				<div class="portfolio-details">
					<a>
						<h2>En Cualquier Parte</h2>
					</a>
				</div>
				<img src="../imagenes/phot4.jpg" class="img-fluid" alt="Portfolio 04">
			</div>
		</div>
	</div>

	<footer class="bgDark">
		<div class="container">
			<h2 style="font-size: 30px"> <span><b>WorkBook</b></span></h2>
			<ul class="list-inline">
				<li class="list-inline-item footer-menu"><a href="inicio.php">Inicio</a></li>
					
				<li class="list-inline-item footer-menu"><a href="acercade.php">Acerca de Nosotros</a></li>
				<li class="list-inline-item footer-menu"><a href="../formulario/formulariocontac.html">Contact</a></li>
				<li class="list-inline-item footer-menu"><a href="terminoycondiciones.html">Termino y Condiciones</a></li>
			</ul>
			<ul class="list-inline">
				<li class="list-inline-item"><a href="http://www.instagram.com"><i
							class="icon ion-logo-instagram"></i></a></li>
				<li class="list-inline-item"><a href="http://www.facebook.com"><i
							class="icon ion-logo-facebook"></i></a></li>
				<li class="list-inline-item"><a href="http://www.youtube.com"><i class="icon ion-logo-youtube"></i></a>
				</li>
				<li class="list-inline-item"><a href="http://www.whatsapp.com"><i
							class="icon ion-logo-whatsapp"></i></a></li>
				<li class="list-inline-item"><a href="http://www.twitter.com"><i class="icon ion-logo-twitter"></i></a>
				</li>
			</ul>
			<small><b>Desarrollo de Aplicaicones WEB UG.</b> ©2020 All Rights Reserved. Created by Grupo </small>
		</div>
	</footer>


	<!-- Optional JavaScript Bootstrap -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
		integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
		crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"
		integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN"
		crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"
		integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV"
		crossorigin="anonymous"></script>
</body>

</html>