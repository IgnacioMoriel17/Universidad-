<?php
$usuario=$_POST['user'];
$pass=$_POST['pass_user'];

$connexion=mysqli_connect("localhost", "root", "","workbookbd");
$consulta="SELECT *FROM usuarios WHERE usuario='user' and pass='password' "; 
$resultado=mysqli_query($connexion, $consulta);

if(empty($resultado) AND mysqli_num_rows($resultado) > 0){    
    header("localhost:quesomos.html");
}
else{
    echo"mal";
}

mysqli_close($connexion);
