// JavaScript Document

window.onload = enviar; 

function enviar(){// Asociar la funcion validar al evento click de el boton Enviar
    document.getElementById('enviar').addEventListener('click',validar,false);    
}

function validaidentificacion(){
	var identificacion = document.getElementById('identificacion');
	limpiarError(identificacion);
	if(identificacion.value ==''){
		alert ('El campo de Identificacion es obligatorio');
		error(identificacion);
		return false;
	}
	else if(isNaN(identificacion.value)){
		alert('Formato de Identificacion debe ser numeros');
		error(identificacion);
		return false;	
	}
	else if(identificacion.value.length<10){
		alert('Error: Solo se debe ingresar minimo 10 digitos');
		error(identificacion);
		return false;
	}
	else if(identificacion.value.length>10){
		alert('Error: solo se debe ingresar maximo 10 digitos');
		error(identificacion);
		return false;
	}return true;
}


function validanombre(){
	var nombre = document.getElementById('nombre');
	limpiarError(nombre);
	if (nombre.value ==''){
		alert ('El campo de Nombre es obligatorio');
		error(nombre);
		return false;
	}
	else if(!isNaN(nombre.value)){
		alert('Formato del Nombre debe ser Letras');
		error(nombre);
		return false;	
	}return true
}

function validapapellido(){
	var papellido = document.getElementById('papellido');
	limpiarError(papellido);
	if (papellido.value==''){
		alert('El campo de Apellido Paterno no debe estar vacio');
		error(papellido);
		return false;
	}
	else if(!isNaN(papellido.value)){
		alert('Formato del Apellido Paterno debe ser Letras');
		error(papellido);
		return false;	
	}return true;
}

function validamapellido(){
	var mapellido = document.getElementById('mapellido');
	limpiarError(mapellido);
	if (mapellido.value==''){
		alert('El campo de Apellido Materno no debe estar vacio');
		error(mapellido);
		return false;
	}
	else if(!isNaN(mapellido.value)){
		alert('Formato del Apellido Materno debe ser Letras');
		error(mapellido);
		return false;	
	}return true;
}


function validaemail(){
	var email = document.getElementById('email');
	limpiarError(email);
	if (email.value ==''){
		alert('El campo del Correo es obligatorio');
		error(email);
		return false;
	}
	var expresion = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	if(email.value.match(expresion)){
		return true;
	}
	else{
		alert("EL formato del Correo en invalido");
		error(email);
		return false;
	}
}

function validanumero(){
		var celular = document.getElementById('celular');
		limpiarError(celular);
		if (celular.value ==''){
			alert('El campo del Celular no debe ir vacio');
			error(celular);
			return false;
		}
	else if(isNaN(celular.value)){
		alert('Formato del campo Celular  debe ser numerico');
		error(celular);
		return false;	
	}
	else if(celular.value.length<10){
		alert('Error: Solo se debe ingresar minimo 10 digitos');
		error(celular);
		return false;
	}
	else if(celular.value.length>10){
		alert('Error: solo se debe ingresar maximo 10 digitos');
		error(celular);
		return false;
	}return true;
}

function valuedirecion(){
	var direcion = document.getElementById('direccion');
	limpiarError(direcion);
	if (direcion.value==''){
		alert('El campo Direcion domiciliaria no debe ir vacio');
		error(direcion);
		return false;
	}return true;
}

function valueciudad(){
	var ciudad = document.getElementById('ciudad');
	limpiarError(ciudad);
	if (ciudad.value==''){
		alert('El campo de Ciudad no debe ir vacio');
		error(ciudad);
		return false;
	}return true;
}

function valueprovincias(){
	var  provincia = document.getElementById('provincia').selectedIndex;
	if(provincia == null || provincia == 0){
			alert('Seleccion una Provincia');
			return false;
	}return true;
}

function valueaficiones(){
	var aficiones = document.getElementById('aficiones').checked;
	if(aficiones) {
		return true;
	}
	else{
		alert('Selecione al menos una Aficion ');
		return false;
	}
	
}





function validar (e){
	if (validaidentificacion() && validanombre() && validapapellido() && validamapellido() && validaemail() && validanumero() && valuedirecion() && valueciudad() && valueprovincias() && valueaficiones() && confirm('Pulsa aceptar si desea enviar sus cambios')){
		return false;
	}else {
		e.preventDefault();
		return false;
	}
}


function error(elemento){
	elemento.style.backgroundColor = "#FEDAD3";
	elemento.style.border= "solid 1px red" ;
    elemento.className = "error";
    elemento.focus();
}

function limpiarError(elemento){
    elemento.className = " ";
	elemento.style.border="solid 1px black";
	elemento.style.backgroundColor = "#FCFCFC";
}