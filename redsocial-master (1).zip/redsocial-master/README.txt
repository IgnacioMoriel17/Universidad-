Configuro Web | Red Social

**DETALLES DE REGISTRO**

Nombre de usuario: configuroweb
Contraseña: 1234abcd..

Igual puedes solo registrarte como usuario


Debes crear una base de datos de nombre socialdb con UTF8 spanish 2

Después importas la bd ubicada dentro del proyecto, en la carpeta de nombre DATABASE