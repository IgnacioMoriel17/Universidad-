<?php
 $host = "localhost";
 $user = "root";
 $clave = "";
 $bd = "ejmploxd";
 $conectar = mysqli_connect($host,$user,$clave,$bd);
 ?>