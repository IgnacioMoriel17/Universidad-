<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="../home/est_terminosycondc.css" rel="stylesheet">
    <link href="https://unpkg.com/ionicons@4.5.5/dist/css/ionicons.min.css" rel="stylesheet">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
        integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <!--Animacion de ciertas Etiquetas-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.0.0/animate.min.css" />
    <!--Efecto Scroll en imagen-->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <script src="parallax.min.js"></script>


    <title>WorkBook|Que Somos?</title>
</head>

<body>
    <nav class="navbar navbar-expand-lg">
        <div class="container">
            <a class="navbar-brand disabled animate__animated animate__slideInLeft"
                style="font-size: 35px; color: white;">WorkBook</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <i class="icon ion-md-menu"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item"><a class="nav-link" href="../index.php" id="login">Login</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="letracentro">
        <h1>Losentimos no estas registrado :( </h1>
        <a href="../registro_user/form_user.php" style="text-decoration: none;"><h2 style="text-align:center;"> <span>Registrate ;)</span> </h2></a>
    </div>

   

    

   



    <footer class="bgDark">
        <div class="container">
            <h2 style="font-size: 30px; color:rgb(95, 204, 255)"><b>WorkBook</b></h2>
            <ul class="list-inline">
                
                <li class="list-inline-item footer-menu"><a href="../login/from_contacto_login.php"  style="font-weight: 700;">Contact</a></li>
            </ul>
            <ul class="list-inline">
                <li class="list-inline-item"><a href="http://www.instagram.com"><i
                            class="icon ion-logo-instagram"></i></a></li>
                <li class="list-inline-item"><a href="http://www.facebook.com"><i
                            class="icon ion-logo-facebook"></i></a></li>
                <li class="list-inline-item"><a href="http://www.youtube.com"><i class="icon ion-logo-youtube"></i></a>
                </li>
                <li class="list-inline-item"><a href="http://www.whatsapp.com"><i
                            class="icon ion-logo-whatsapp"></i></a></li>
                <li class="list-inline-item"><a href="http://www.twitter.com"><i class="icon ion-logo-twitter"></i></a>
                </li>
            </ul>
            <small>©2020 All Rights Reserved. Created by Grupo <b>D.A.W con Bootstrap</b></small>
        </div>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"
        integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN"
        crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"
        integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV"
        crossorigin="anonymous"></script>
</body>

</html>