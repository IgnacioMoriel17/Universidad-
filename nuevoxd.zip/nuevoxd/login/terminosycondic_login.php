<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="../home/est_terminosycondc.css" rel="stylesheet">
    <link href="https://unpkg.com/ionicons@4.5.5/dist/css/ionicons.min.css" rel="stylesheet">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
        integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <!--Animacion de ciertas Etiquetas-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.0.0/animate.min.css" />
    <!--Efecto Scroll en imagen-->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <script src="parallax.min.js"></script>


    <title>WorkBook|Que Somos?</title>
</head>

<body>
    <nav class="navbar navbar-expand-lg">
        <div class="container">
            <a class="navbar-brand disabled animate__animated animate__slideInLeft"
                style="font-size: 35px; color: white;">WorkBook</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <i class="icon ion-md-menu"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item"><a class="nav-link" href="../index.php" id="login">Login</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="letracentro">
        <h1>Terminos y Condiciones del Servicio <span>WorkBook</span></h1>
    </div>

    <section>
        <div class="contenedor">
            <div class="descrip_img">
                <div class="letras">
                    <h2>1. Quién puede hacer uso de los Servicios</h2>
                    <p>Puede hacer uso de los Servicios si usted cuenta con un titulo de tercer nivel, tecnico superior,
                        maestria, doctorado o ser propietario de una empresa, microempra o franquicia registradas en el
                        SRI y no es usted una persona vetada para hacer uso de los servicios de conformidad con la
                        legislación de su jurisdicción aplicable.<br>
                        En cualquier caso, usted deberá ser mayor de 18 años y no tener cargos judiciales, para hacer
                        uso de los Servicios. Si acepta estos Términos y usa los Servicios en nombre de una empresa,
                        organización, gobierno u otra entidad jurídica, afirma y garantiza que está autorizado a hacerlo
                        y cuenta con los poderes necesarios para obligarla al cumplimiento de estos Términos.</p>
                </div>
            </div>
        </div>
    </section>

    <section>
        <div class="contenedor">
            <div class="descrip_img2">
                <div class="letras">
                    <h2>2. Privacidad</h2>
                    <p>WorkBook es público y las publicaciones pueden ser vistos y buscados por cualquier persona en
                        todo el mundo. También le proporcionamos formas de comunicarse en WorkBook que no son públicas
                        mediante publicaciones protegidos y Mensajes directos. Usted también puede utilizar WorkBook
                        bajo un seudónimo si prefiere no utilizar su nombre.<br>
                        Cuando usted utiliza WorkBook, incluso si solo está mirando publicaciones, recibimos alguna
                        información personal de usted como el tipo de dispositivo que está utilizando y su dirección IP.
                        Usted puede optar por compartir información adicional con nosotros como su dirección de correo
                        electrónico, número de teléfono, contactos de la agenda y perfil público. Utilizamos esta
                        información para cuestiones como el mantenimiento de la seguridad de su cuenta y para mostrarle
                        publicaciones, personas que seguir, eventos y anuncios más relevantes.</p>
                </div>
            </div>
        </div>
    </section>

    <section>
        <div class="contenedor">
            <div class="descrip_img3">
                <div class="letras">
                    <h2>3. Contenido de los Servicios</h2>
                    <p>Cualquier confianza que deposite en cualquier Contenido o material publicado por medio de los
                        Servicios u obtenido mediante los mismos, o cualquier uso que haga de ellos, lo hace por su
                        propia cuenta y riesgo. <br>
                        Cualquier confianza que deposite en cualquier Contenido o material publicado por medio de los
                        Servicios u obtenido mediante los mismos, o cualquier uso que haga de ellos, lo hace por su
                        propia cuenta y riesgo. No ratificamos, apoyamos, reafirmamos ni garantizamos la compleción,
                        veracidad, precisión o fiabilidad de ningún Contenido o comunicación publicada por medio de los
                        Servicios, ni ratificamos ninguna opinión expresada por medio de los Servicios.</p>
                </div>
            </div>
        </div>
    </section>



    <footer class="bgDark">
        <div class="container">
            <h2 style="font-size: 30px; color:rgb(95, 204, 255)"><b>WorkBook</b></h2>
            <ul class="list-inline">
                
                <li class="list-inline-item footer-menu"><a href="from_contacto_login.php"  style="font-weight: 700;">Contact</a></li>
            </ul>
            <ul class="list-inline">
                <li class="list-inline-item"><a href="http://www.instagram.com"><i
                            class="icon ion-logo-instagram"></i></a></li>
                <li class="list-inline-item"><a href="http://www.facebook.com"><i
                            class="icon ion-logo-facebook"></i></a></li>
                <li class="list-inline-item"><a href="http://www.youtube.com"><i class="icon ion-logo-youtube"></i></a>
                </li>
                <li class="list-inline-item"><a href="http://www.whatsapp.com"><i
                            class="icon ion-logo-whatsapp"></i></a></li>
                <li class="list-inline-item"><a href="http://www.twitter.com"><i class="icon ion-logo-twitter"></i></a>
                </li>
            </ul>
            <small>©2020 All Rights Reserved. Created by Grupo <b>D.A.W con Bootstrap</b></small>
        </div>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"
        integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN"
        crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"
        integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV"
        crossorigin="anonymous"></script>
</body>

</html>