
window.onload = enviar; 

function enviar(){// Asociar la funcion validar al evento click de el boton Enviar
document.getElementById('enviarcontac').addEventListener('click',validar,false);    
	}
/************************************************************Validacion Nombre*/
	function validanombre(){
		var nombre = document.getElementById('nombre');
		limpiarError(nombre);
		if (nombre.value ==''){
			alert ('El campo de nombre es obligatorio');
			error(nombre);
			return false;
		}
		else if(!isNaN(nombre.value)){
			alert('Formato del nombre debe ser Letras');
			error(nombre);
			return false;	
		}return true
	}
/************************************************************Validacion Email*/
	function validaemail(){
		var email = document.getElementById('correo');
		limpiarError(email);
		if (email.value ==''){
			alert('El campo del correo es obligatorio');
			error(email);
			return false;
		}
		var expresion = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
		if(email.value.match(expresion)){
			return true;
		}
		else{
			alert("EL formato del correo en invalido");
			error(email);
			return false;
		}
	}
/************************************************************Validacion Celular*/
	function validacell(){
			var cell = document.getElementById('cell');
			limpiarError(cell);
			if (cell.value ==''){
				alert('El campo del celular no debe ir vacio');
				error(cell);
				return false;
			}
		else if(isNaN(cell.value)){
			alert('Formato del campo celular  debe ser numerico');
			error(cell);
			return false;	
		}
		else if(cell.value.length<10){
			alert('Error: Solo se debe ingresar minimo 10 digitos');
			error(cell);
			return false;
		}
		else if(cell.value.length>10){
			alert('Error: solo se debe ingresar maximo 10 digitos');
			error(cell);
			return false;
		}return true;
	}
/************************************************************Validacion Asunto*/
	function validaasunto(){
		var asunto = document.getElementById('asunto');
		limpiarError(asunto);
		if (asunto.value ==''){
			alert ('El campo de asunto es obligatorio');
			error(asunto);
			return false;
		}
		else if(!isNaN(asunto.value)){
			alert('Formato de asunto debe ser Letras');
			error(asunto);
			return false;	
		}return true
	}
/************************************************************Validacion Mensaje*/
	function validamensaje(){
		var mensaje = document.getElementById('mensaje');
		limpiarError(mensaje);
		if (mensaje.value ==''){
			alert ('El campo mensaje es obligatorio');
			error(mensaje);
			return false;
		}
		else if(!isNaN(mensaje.value)){
			alert('Formato mensaje debe ser Letras');
			error(mensaje);
			return false;	
		}return true
	}
/************************************************************Funcion Validar*/
	function validar (e){
		if ( validanombre() && validaemail() && validacell() && validaasunto() && validamensaje() &&confirm('Pulsa aceptar si desea enviar sus cambios')){
			return false;
		}else {
			e.preventDefault();
			return false;
		}
	}


	function error(elemento){
		elemento.className = "error";
		elemento.focus();
	}

	function limpiarError(elemento){
		elemento.className = " ";
		
	}// JavaScript Document        